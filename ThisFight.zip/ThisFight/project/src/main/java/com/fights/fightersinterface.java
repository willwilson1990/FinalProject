package com.fights;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface fightersinterface extends CrudRepository <fighters, Integer>{

	@Modifying
	@Transactional
	@Query(value = "update fighters set record = :newRecord where id = :id", nativeQuery = true)
	void updateByRecord(int id, String newRecord);

	

	
}
