package com.fights.controllers.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fights.fightcardinterface;
import com.fights.fighters;
import com.fights.fightersinterface;
import com.fights.fights;
import com.fights.fightsinterface;
import com.fights.fightcard;

@RestController
public class fightcardcontroller {

	@Autowired
	fightcardinterface fightcard;
	@Autowired
	fightsinterface fights;
	@Autowired
	fightersinterface fighters;
	@Autowired
	fightsinterface ischampionshipfight;
	
	@CrossOrigin(origins="*")
	@GetMapping(value="/fighters/{text}") 
	public List<fights> fightersName(@PathVariable String text){
		
		String name = text;
		List<fights> bob = fights.findByFighter1ORFighter2(name);
		
		return bob;
	}
	
	@CrossOrigin(origins="*")
	@GetMapping(value="/fightcardinfo/{text}")  
	public List<fightcard> fightcardinfo(@PathVariable String text){
		
		String name = text;
		List<fightcard> bob = fightcard.findByName(name);
		
		return bob;
	}
	
	@CrossOrigin(origins="*")
	@GetMapping(value="/fightcard/{text}")  
	public List<fights> fightcardName(@PathVariable String text){
		
		String name = text;
		List<fights> bob = fights.findByFightcard(name);
		
		return bob;
	}
	
	@CrossOrigin(origins="*")
	@GetMapping(value="/titleholders/{division}/{ischampionshipfight}")  
	public List<fights> titleholders(@PathVariable("division") int division, @PathVariable("ischampionshipfight") boolean ischampionshipfight) {
		
		int div = division;
		boolean champ = ischampionshipfight;
		List<fights> bob = fights.findByFights(div, champ);
		
		return bob;
	}
	
	@CrossOrigin(origins="*")
	@PostMapping(value = "/addfightcard/{name}/{location}/{image}/{numoffights}/{date}")
	@ResponseBody
	public fightcard postNewFightcard(@PathVariable("name") String name, @PathVariable("location") String location, @PathVariable("image")String image, @PathVariable("numoffights") int numoffights, @PathVariable("date") String date) {
			
			fightcard cardAdded = new fightcard(name, location, image, numoffights, date);
			fightcard.save(cardAdded);
	return cardAdded;
	}
	
	@CrossOrigin(origins="*")
	@PostMapping(value = "/addfighter/{name}/{fightingoutof}/{dob}/{gender}/{height}/{record}")
	@ResponseBody
	public fighters postNewFighter(@PathVariable("record") String record, @PathVariable("name") String name, @PathVariable("fightingoutof") String fightingoutof, @PathVariable("dob")String dob, @PathVariable("gender") String gender, @PathVariable("height") String height) {
			
			fighters fighterAdded = new fighters( name, fightingoutof, dob, gender, height, record);
			fighters.save(fighterAdded);
			
	return fighterAdded;
	}
	
	@CrossOrigin(value="*")
	@PostMapping(value = "/addfight/{fighter1}/{fighter2}/{finishingstyle}/{fightcard}/{ischampionshipfight}/{numofrounds}/{timeoffinish}/{division}/{finishingmove}")
	@ResponseBody
	public fights postNewFight(@PathVariable("fighter1") String fighter1, @PathVariable("fighter2") String fighter2, @PathVariable("finishingstyle")String finishingstyle, @PathVariable("fightcard") String fightcard, @PathVariable("ischampionshipfight") boolean ischampionshipfight, @PathVariable("numofrounds") int numofrounds, @PathVariable("timeoffinish") String timeoffinish, @PathVariable("division") String division, @PathVariable("finishingmove") String finishingmove) {
			
		fights fightAdded = new fights(fighter1, fighter2, finishingstyle, fightcard, ischampionshipfight, numofrounds, timeoffinish, division, finishingmove);
		fights.save(fightAdded);
		
	return fightAdded;
	}
	
	@CrossOrigin(origins="*")
	@PutMapping(value = "/updaterecord/{id}/{record}")
	public boolean updateRecord(@PathVariable("id") int text,@PathVariable("record") String text2) {
		boolean newRecord = true;
		fighters.updateByRecord(text, text2);
		
		return newRecord;
	}
	
	@CrossOrigin(origins="*")
	@PostMapping(value = "/updateresult/{id}/{style}/{move}")
	public boolean updateFinishingResult(@PathVariable("id") int text,@PathVariable("style") String text2,@PathVariable("move") String text3) {
		boolean newStyle = true;
		fights.updateByFinishingResult(text, text2, text3);
		
		return newStyle;
	}
	
	/*@CrossOrigin(origins="*")
	@PutMapping(value = "/Updatefinishingmove/{id}/{new}")
	public boolean updateFinishingMove(@PathVariable("id") String text,@PathVariable("new") String text2) {
		boolean newMove = true;
		fights.updateByFinishingMove(text, text2);
		
		return newMove;
	}*/
	
	
	
	/*@DeleteMapping(value = "/Deletefight")
		public boolean{
		boolean res = true;
		
		return res;
		}*
		
	@DeleteMapping(value = "/Deletecard")
		public boolean{
		boolean res = true;
		
		return res;
		}*/
}
