package com.fights;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class finishingstyle {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String stylename;
	String styleimage;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStylename() {
		return stylename;
	}
	public void setStylename(String stylename) {
		this.stylename = stylename;
	}
	public String getStyleimage() {
		return styleimage;
	}
	public void setStyleimage(String styleimage) {
		this.styleimage = styleimage;
	}
}
