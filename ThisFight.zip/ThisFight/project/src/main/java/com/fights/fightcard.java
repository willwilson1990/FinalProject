package com.fights;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class fightcard {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String name;
	String location;
	String image;
	int numoffights;
	String date;
	
	public fightcard() {
		super();
	}

	public fightcard(String name, String location, String image, int numoffights, String date) {
		super();
		this.name = name;
		this.location = location;
		this.image = image;
		this.numoffights = numoffights;
		this.date = date;
	}
	
	public int getNumoffights() {
		return numoffights;
	}
	public void setNumoffights(int numoffights) {
		this.numoffights = numoffights;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
}