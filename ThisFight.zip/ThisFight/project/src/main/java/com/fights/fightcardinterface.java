package com.fights;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface fightcardinterface extends CrudRepository <fightcard, Integer>{

	List<fightcard> findByName(String name);

	
	
} 