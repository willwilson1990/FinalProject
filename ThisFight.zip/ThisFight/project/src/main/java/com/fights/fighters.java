package com.fights;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class fighters {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String name;
	String fightingoutof;
	String dob;
	String gender;
	String height;
	String record;
	
	public fighters() {
		super();
	}


	public fighters(String name, String fightingoutof, String dob, String gender, String height, String record) {
		super();
		this.name = name;
		this.fightingoutof = fightingoutof;
		this.dob = dob;
		this.gender = gender;
		this.height = height;
		this.record = record;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFightingoutof() {
		return fightingoutof;
	}
	public void setFightingoutof(String fightingoutof) {
		this.fightingoutof = fightingoutof;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getRecord() {
		return record;
	}
	public void setRecord(String record) {
		this.record = record;
	}
}

