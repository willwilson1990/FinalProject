package com.fights;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class fights {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String fighter1;
	String fighter2;
	String finishingstyle;
	String fightcard;
	boolean ischampionshipfight;
	int numofrounds;
	String timeoffinish;
	String division;
	String finishingmove;
	
	
	
	public fights() {
		super();
	}

	public fights(String fighter1, String fighter2, String finishingstyle, String fightcard,
			boolean ischampionshipfight, int numofrounds, String timeoffinish, String division2, String finishingmove) {
		super();
		this.fighter1 = fighter1;
		this.fighter2 = fighter2;
		this.finishingstyle = finishingstyle;
		this.fightcard = fightcard;
		this.ischampionshipfight = ischampionshipfight;
		this.numofrounds = numofrounds;
		this.timeoffinish = timeoffinish;
		this.division = division2;
		this.finishingmove = finishingmove;
	}
	
	public String getTimeoffinish() {
		return timeoffinish;
	}
	public void setTimeoffinish(String timeoffinish) {
		this.timeoffinish = timeoffinish;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFighter1() {
		return fighter1;
	}
	public void setFighter1(String fighter1) {
		this.fighter1 = fighter1;
	}
	public String getFighter2() {
		return fighter2;
	}
	public void setFighter2(String fighter2) {
		this.fighter2 = fighter2;
	}
	public String getFinishingstyle() {
		return finishingstyle;
	}
	public void setFinishingstyle(String finishingstyle) {
		this.finishingstyle = finishingstyle;
	}
	public String getFightcard() {
		return fightcard;
	}
	public void setFightcard(String fightcard) {
		this.fightcard = fightcard;
	}
	public boolean isIschampionshipfight() {
		return ischampionshipfight;
	}
	public void setIschampionshipfight(boolean ischampionshipfight) {
		this.ischampionshipfight = ischampionshipfight;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public int getNumofrounds() {
		return numofrounds;
	}
	public void setNumofrounds(int numofrounds) {
		this.numofrounds = numofrounds;
	}
	public String getFinishingmove() {
		return finishingmove;
	}
	public void setFinishingmove(String finishingmove) {
		this.finishingmove = finishingmove;
	}
}

