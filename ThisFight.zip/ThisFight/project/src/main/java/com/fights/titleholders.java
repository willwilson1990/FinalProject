package com.fights;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class titleholders {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	int division;
	String name;
	String reign;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDivision() {
		return division;
	}
	public void setDivision(int division) {
		this.division = division;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getReign() {
		return reign;
	}
	public void setReign(String reign) {
		this.reign = reign;
	}
	
	
}  