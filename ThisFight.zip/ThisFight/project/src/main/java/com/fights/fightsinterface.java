package com.fights;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface fightsinterface  extends CrudRepository <fights, Integer>{

	ArrayList<fights> findByFightcard (String Fightcard);
	ArrayList<fights> findByFighter1 (String fighter1);
	ArrayList<fights> findByFighter2 (String fighter2);

	@Query (value = "select * from fights where fights.Fighter1 = :fighterid", nativeQuery = true)
	ArrayList<fights> fightsByFighterOne(int fighterid);
	
	@Query (value = "select * from fights where fights.Fighter2 = :fighterid", nativeQuery = true)
	ArrayList<fights> fightsByFighterTwo(int fighterid);	
	
	@Query (value = "select * from fighters where fighters.id in (select Fighter1 from fights where fights.id = :fightsid", nativeQuery = true) 
	ArrayList<fights> fightsByFightsOne(int fightsid);
	
	@Query (value = "select * from fighters where fighters.id in (select Fighter2 from fights where fights.id = :fightsid", nativeQuery = true)
	ArrayList<fights> fightsByFightsTwo(int fightsid);
	
	@Query (value = "select * from fighters where fighters.id in (select Fighter1 from fights where fights.id = :fightsid", nativeQuery = true) 
	ArrayList<fights> fightsByFightcardOne(int fightsid);
	
	@Query (value = "select * from fighters where fighters.id in (select Fighter2 from fights where fights.id = :fightsid", nativeQuery = true)
	ArrayList<fights> fightsByFightcardTwo(int fightsid);
	
	@Query (value = "insert into fightcard(name, location, image, numoffights, date)"
			 + "values (:newname, :newlocation, :newimage, :newnumoffights, :newdate)", nativeQuery = true)
	void postNewFightcard(String newname, String newlocation, String newimage, int newnumoffights, String newdate);

	@Query (value = "insert into fights(fighter1, fighter2, finishingstyle, fightcard, ischampionshipfight, numofrounds, timeoffinish, division, finishingmove)"
			+ "values (:newfighter1, :newfighter2, :newfinishingstyle, :newfightcard, :newischampionshipfight, :newnumofrounds, :newtimeoffinish, :newdivision, :newfinishingmove)", nativeQuery = true)
	void postNewFight(String newfighter1, String newfighter2, String newfinishingstyle, String newfightcard, boolean newischampionshipfight, int newnumofrounds, String newtimeoffinish, int newdivision, String newfinishingmove);
	
	@Modifying
	@Transactional
	@Query(value = "update fights set finishingStyle = :newFinishingStyle, finishingMove = :newFinishingMove where id = :id", nativeQuery = true)
	void updateByFinishingResult( int id, String newFinishingStyle, String newFinishingMove);
	
	/*@Modifying
	@Transactional
	@Query(value = "update fights set finishingMove = :newFinishingMove where id = :id", nativeQuery = true)
	void updateByFinishingMove(@Param("id") String text, @Param("newFinishingMove") String text2);*/
	
	@Query (value = "select * from fights where fights.division = :division and fights.ischampionshipfight = :ischampionshipfight", nativeQuery = true) 
	ArrayList<fights> findByFights(int division, boolean ischampionshipfight);
	
	@Query(value= "select * from fights where fights.fighter1 = :fighter or fights.fighter2 = :fighter", nativeQuery = true)
	ArrayList<fights> findByFighter1ORFighter2(String fighter);
	
	
}