package com.fights;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class title {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	boolean isvacant;
	boolean isinterim;
	String image;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public boolean isIsvacant() {
		return isvacant;
	}
	public void setIsvacant(boolean isvacant) {
		this.isvacant = isvacant;
	}
	public boolean isIsinterim() {
		return isinterim;
	}
	public void setIsinterim(boolean isinterim) {
		this.isinterim = isinterim;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	
}
