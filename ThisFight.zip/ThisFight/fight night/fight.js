
var app = angular.module('GETapp', []);
app.controller('GETctrl', function($scope,$http){
$scope.name ='Choose Fighter';

$scope.makeURL = function(name){
var url = 'http://localhost:8080/fighters/'+name


console.log(url);
//call the services

$http.get(url).then(function (response) {

if (response.data)
$scope.output = response.data;
$scope.msg = "Get Data Method Executed Successfully!";

}, function (response) {

$scope.msg = "Service not Exists";
        
$scope.statusval = response.status;

$scope.statustext = response.statusText;

$scope.headers = response.headers();

});

};

});