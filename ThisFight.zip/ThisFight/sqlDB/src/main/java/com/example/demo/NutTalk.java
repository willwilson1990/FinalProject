package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface NutTalk extends CrudRepository <nuts, Integer>{

	List<nuts> findByTexture(String texture);

	List<nuts> findByName(String name);

	List<nuts> findByColor(String color);

	@Query(value = "select n.* from [saladIngredient] si join salad s on s.id = si.sid join nuts n on isNut = 1 and n.id = NutID", nativeQuery = true)
	List<nuts> DemSaladNuts();
	
	@Query(value = "select * from nuts where texture = :texture and color = :color", nativeQuery = true)
	List <nuts> textureAndColor (@Param("texture") String Texture, @Param("color") String Color);
	
	List<nuts> findByTextureAndColor(String texture, String color);
	
	List<nuts> findByTextureOrColor(String texture, String color);
	
	@Modifying
	@Transactional
	@Query(value = "update nuts set texture = :newTexture where texture = :oldTexture", nativeQuery = true)
	void updateByTexture(@Param("oldTexture")String oldT, @Param("newTexture") String newT);

	/*@Modifying
	@Transactional
	@Query(value = "insert into nuts (id, name, texture, averageCount, Edible, color)"
			+ " values(id=:newid, name=:newname, texture=:newtexture, averagecount=:newaveragecount,"
			+ " edible=:newedible, color=:newcolor)", nativeQuery = true) //you can take out the + and combine them into one long line
	void postNewnut(int newid, String newname, String newtexture, int newaveragecount, int newedible, String newcolor);*/

}
//NutTalk is a repository. It is what is talking to the table of nuts in the data scheam