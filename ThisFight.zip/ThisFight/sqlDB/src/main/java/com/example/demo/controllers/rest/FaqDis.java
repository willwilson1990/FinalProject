package com.example.demo.controllers.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.NutTalk;
import com.example.demo.nuts;

@RestController
public class FaqDis {
	
	@Autowired
	NutTalk bagOnuts;

	@GetMapping(value = "/Something")
	public String frig() {
		return "frig off !";
	}
	
	@GetMapping(value = "/CheckOn")
	public String Check() {
		return "hello world !";
	}
	
	@GetMapping(value = "/nuts/count/")
	public Long Count() {
		long numberOnuts = bagOnuts.count();
		
		return numberOnuts;
	}
	
	@GetMapping(value = "/nuts/texture/{text}")
	public List<nuts> nutsTexture(@PathVariable String text) {
		
		String texture = text ;
		List<nuts> Deez = bagOnuts.findByTexture(texture);
		
		return Deez;
	}
	
	@GetMapping(value = "/nuts/color/{text}")
	public List<nuts> nutsColor(@PathVariable String text) {
		
		String color = text ;
		List<nuts> Deez = bagOnuts.findByColor(color);
		
		return Deez;
	}
	
	@GetMapping(value = "/nuts/color/")
	public List<nuts> nutsColor2(@RequestParam("color")String text){
		String color = text;
		List<nuts> Deez = bagOnuts.findByColor(color);
		
		return Deez;
	}
	
	@GetMapping(value = "/nuts/name/{text}")
	public List<nuts> nutsName(@PathVariable String text) {
		
		String name = text ;
		List<nuts> Deez = bagOnuts.findByName(name);
		
		return Deez;
	}
	
	@GetMapping(value = "/nuts/demSalad")
	public List<nuts> nutsSalad() {
		
		List<nuts> Deez = bagOnuts.DemSaladNuts();
		
		return Deez;
	}
	
	@GetMapping(value = "/nuts/{text},{text2}")
	public List<nuts> textureAndColor(@PathVariable ("text") String Texture, @PathVariable ("text2") String Color){
		List<nuts> Deez = bagOnuts.textureAndColor(Texture, Color);
		
		return Deez;
	}
	
	@GetMapping(value = "/nuts/{text}&{text2}")
	public List<nuts> AUTOtextureAndColor(@PathVariable ("text") String Texture, @PathVariable ("text2") String Color){
		List<nuts> Deez = bagOnuts.findByTextureAndColor(Texture, Color);
		
		return Deez;
	}
	
	@GetMapping(value = "/nuts/{text}-{text2}")
	public List<nuts> textureOrColor(@PathVariable ("text") String Texture, @PathVariable ("text2") String Color){
		List<nuts> Deez = bagOnuts.findByTextureOrColor(Texture, Color);
		
		return Deez;
	}

//@PutMapping is changing information. Like changing the texture from "soft" to "hard".
	@PutMapping(value = "/CheckOn/{old}/{new}")
	public boolean updateTexture(@PathVariable("old") String text,@PathVariable("new") String text2) {
		boolean res = true;
		bagOnuts.updateByTexture(text, text2);
		
		return res;
	}
	
	@GetMapping(value= "/nuts")
	public Iterable<nuts> findAll(){
		return bagOnuts.findAll();
	}

/*@DeleteMapping
	@DeleteMapping(value = "/CheckOn/")
	public boolean
		boolean res = true;
		
		return res;
		}*/
	
/*@PostMapping   1st way (hard as hell)
	@PostMapping(value = "/newNut/{name}/{texture}/{averageCount}/{edible}/{color}")
	public void postNewnut(@PathVariable("id")int id, @PathVariable("name")String name, @PathVariable("texture") String texture, @PathVariable("averagecount")
	int averagecount, @PathVariable("edible") int edible, @PathVariable("color") String color){
		bagOnuts.postNewnut(id, name, texture, averagecount, edible, color);
	}*/
	
	@PostMapping(value = "/CheckOn")
	@ResponseBody
	public nuts Post(@RequestParam("name") String name, @RequestParam("texture") String texture, @RequestParam("averagecount") int averagecount, @RequestParam("edible")int edible, @RequestParam("color") String color) {
		
			nuts ThisNut = new nuts(name, texture, averagecount, edible, color);
			bagOnuts.save(ThisNut);
	return ThisNut;
	}
}
