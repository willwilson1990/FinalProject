package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class nuts {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	private String name;
	private String texture;
	private int averagecount;
	private int edible;
	private String color;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTexture() {
		return texture;
	}
	public void setTexture(String texture) {
		this.texture = texture;
	}
	public int getAveragecount() {
		return averagecount;
	}
	public void setAveragecount(int averagecount) {
		this.averagecount = averagecount;
	}
	public int getEdible() {
		return edible;
	}
	public void setEdible(int edible) {
		this.edible = edible;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	public nuts(String name, String texture, int averagecount, int edible, String color) {
		super();
		this.name = name;
		this.texture = texture;
		this.averagecount = averagecount;
		this.edible = edible;
		this.color = color;
	}
	
	public nuts(int id, String name, String texture, int averagecount, int edible, String color) {
		super();
		this.id = id;
		this.name = name;
		this.texture = texture;
		this.averagecount = averagecount;
		this.edible = edible;
		this.color = color;
	}
	
	
}
